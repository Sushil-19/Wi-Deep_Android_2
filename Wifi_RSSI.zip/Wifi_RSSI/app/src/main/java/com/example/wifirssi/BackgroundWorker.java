package com.example.wifirssi;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.ListIterator;

public class BackgroundWorker extends AsyncTask<String,Void,String> {
    Context context;
    String result;
    static WifiManager wifiManager;
    static String tog;
    BackgroundWorker (Context ctx) {
        context = ctx;
    }
    @Override
    protected String doInBackground(String... params) {
        //WifiInfo wifiInfo;
        WifiScanReceiver wifiReceiver = new WifiScanReceiver();
        while(true) {
            if(Main2Activity.c<=0){
                break;
            }
            context.registerReceiver(wifiReceiver, new
                    IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
            wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
            Main2Activity.count = 0;
            int k = 0;
            Main2Activity.flag = true;
            publishProgress();
            try{
                Thread.sleep(1000);
            }catch(Exception e){

            }

        }
        return params[0];
    }

    @Override
    protected void onPreExecute() {

    }
    @Override
    protected void onPostExecute(String resulti) {
        Toast.makeText(context,"Done",Toast.LENGTH_SHORT).show();
        Main2Activity.bt.setText("Generate");
    }

    @Override
    protected void onProgressUpdate(Void... values) {

        wifiManager.startScan();
      //  System.out.println("Scan Complete");
    }

}
class WifiScanReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent intent) {


        if(Main2Activity.c > 0 && intent.getBooleanExtra(WifiManager.EXTRA_RESULTS_UPDATED, false) && Main2Activity.flag){

                Post_Scan obj = new Post_Scan();
                obj.show_results(BackgroundWorker.wifiManager);
                System.out.println("OK DONE");
                Main2Activity.c--;
                Main2Activity.tt.setText(String.valueOf(Main2Activity.c));


        }




    }
}