package com.example.wifirssi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Hashtable;

public class Main2Activity extends AppCompatActivity {

    static int count;
    static int c;
    static int aps;
    static int patch = 1;
    static boolean flag;
    static EditText et;
    static Button bt;
    static TextView tt;
    static EditText et2;
    static Hashtable<String, Integer>
            hm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        hm = new Hashtable<String, Integer>();
        Button bt = (Button)findViewById(R.id.button2);
        bt.setText(String.valueOf(patch));
        et = (EditText)findViewById(R.id.editText);
        et.setText(String.valueOf(1));
        tt = (TextView)findViewById(R.id.textView2);
        tt.setText("0");
    }
    public void Generate(View view){
        bt = (Button)findViewById(R.id.button);
        bt.setText("Wait");
        tt.setText(Main2Activity.et.getText());
        c = Integer.parseInt(Main2Activity.et.getText().toString());
        BackgroundWorker bg = new BackgroundWorker(this);
        bg.execute("Train");

    }
    public void Patch_ch(View view){
        Button bt = (Button)findViewById(R.id.button2);
        bt.setText(String.valueOf(++patch));
    }
}
