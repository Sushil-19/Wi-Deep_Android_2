package com.example.wifirssi;

import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;

public class Post_Scan {
    public void show_results(WifiManager wifiManager){
        List<ScanResult> scan = wifiManager.getScanResults();
        System.out.println(scan.size());
        if(scan.size()>= Main2Activity.aps){
            String baseDir = android.os.Environment.getExternalStorageDirectory().getAbsolutePath();
            baseDir = baseDir + "/" + "samples.txt";
           //ArrayList<String>tmp = new ArrayList<String>(scan.size() + 1);
            for (int i = 0; i < scan.size(); i++) {
                if(Train_Data.mac_aps.contains(scan.get(i).BSSID)) {
                    Main2Activity.hm.put(scan.get(i).BSSID, i);
                }

            }

            try {
                FileOutputStream fo = new FileOutputStream(baseDir,true);
                for (HashMap.Entry<String,Integer> entry : Main2Activity.hm.entrySet()){
                    System.out.println("Written");
                    fo.write((scan.get(entry.getValue()).SSID + " " + scan.get(entry.getValue()).level + " " + scan.get(entry.getValue()).BSSID + " " + String.valueOf(Main2Activity.patch) + " ").getBytes());
                }
                fo.write(("\n").getBytes());
                fo.flush();
                fo.close();

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }else{
            Main2Activity.c++;
        }


        Main2Activity.count = 1;
        Main2Activity.flag = false;
    }
    public String test_result(WifiManager wifiManager) {
        List<ScanResult> scan = wifiManager.getScanResults();
        String str = "";
        for (int i = 0; i < scan.size(); i++) {
            str  = str + scan.get(i).BSSID + "*" + scan.get(i).level + "*";
        }
        //System.out.println(str);
        return str;
    }

}
